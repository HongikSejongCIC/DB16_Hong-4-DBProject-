package frameclass;

import java.awt.BorderLayout; 
import java.awt.EventQueue;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

import datas.DBdata;

import javax.swing.border.BevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JLayeredPane;
import javax.swing.JScrollBar;
import java.awt.Scrollbar;
import java.awt.Panel;
import java.awt.Color;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.ScrollPane;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import java.awt.Checkbox;
import javax.swing.JCheckBox;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.border.SoftBevelBorder;
import java.util.ArrayList;

public class hospital extends JFrame {
	private DBdata DBdatas;
	
	private JPanel contentPane;
	
	//private JTable table_doctor;
	//private JTable table_nurse;
	
	private JTextField t_search;
	private JTextField t_name;
	private JTextField t_pnum;
	private JTextField t_rnum;
	
	
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DBdata DBdatas= new DBdata();
					hospital frame = new hospital(DBdatas);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	

	/**
	 * Create the frame.
	 */
	public hospital(DBdata db) {
		DBdatas = db;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 852, 658);
		contentPane = new JPanel();
		contentPane.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(14, 23, 806, 588);
		contentPane.add(tabbedPane);
		
		//JCheckBox chckbxNewCheckBox = new JCheckBox("New check box");
		//chckbxNewCheckBox.setBounds(128, 30, 131, 27);
		
		String calName[]={"ȯ�ڹ�ȣ","�̸�","��ȭ��ȣ","�ֹι�ȣ"};
		Object data[] = new Object[4];
		JTable table_psearch;
		DefaultTableModel tableModel;
		tableModel = new DefaultTableModel(calName,0);
		table_psearch = new JTable(tableModel);
			
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.LIGHT_GRAY);
		tabbedPane.addTab("ȯ��", null, panel_3, null);
		panel_3.setLayout(null);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_4.setBackground(Color.WHITE);
		panel_4.setBounds(280, 23, 507, 171);
		panel_3.add(panel_4);
		panel_4.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(14, 69, 479, 45);
		panel_4.add(scrollPane_1);
		
		scrollPane_1.setViewportView(table_psearch);
		
		JLabel label = new JLabel("ȯ�� ��ȣ �˻�");
		label.setBounds(14, 34, 106, 18);
		panel_4.add(label);
		
		
		JButton btnNewButton = new JButton("�˻�");
		
		btnNewButton.setBounds(260, 30, 73, 27);
		panel_4.add(btnNewButton);
		
		t_search = new JTextField();
		t_search.setBounds(120, 31, 126, 24);
		panel_4.add(t_search);
		t_search.setColumns(10);
		
		
       ActionListener listener5 = new ActionListener() { //�˻���ư������  
		public void actionPerformed(ActionEvent e) {
			//System.out.println("���Ⱑ "+t_search.getText());
			DBdatas.ȯ�ڰ˻�(t_search.getText(),data,tableModel,table_psearch);
		}
	};
		btnNewButton.addActionListener(listener5); 
		
		
		JButton btnNewButton_1 = new JButton("���᳻�뺸��");
		btnNewButton_1.setBounds(376, 132, 117, 27);
		panel_4.add(btnNewButton_1);
		
		ActionListener listener = new ActionListener() { //���᳻�뺸���ư
			public void actionPerformed(ActionEvent e) {
				new BOOK().setVisible(true);
			}
		};

		btnNewButton_1.addActionListener(listener);
		
		
		JPanel panel_5 = new JPanel();
		panel_5.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_5.setBackground(Color.WHITE);
		panel_5.setBounds(280, 206, 507, 291);
		panel_3.add(panel_5);
		panel_5.setLayout(null);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(14, 41, 479, 164);
		panel_5.add(scrollPane_4);
		
		String calName2[]={"��ȣ","�̸�","��ȭ��ȣ","�ֹι�ȣ","���࿩��"};
		Object data2[] = new Object[5];
		JTable table_patient;
		DefaultTableModel tableModel2;
		
		tableModel2 = new DefaultTableModel(calName2,0);
		table_patient = new JTable(tableModel2);
		
		scrollPane_4.setViewportView(table_patient);
		
		JLabel lblNewLabel = new JLabel("���� ��Ȳ");
		lblNewLabel.setBounds(14, 12, 62, 18);
		panel_5.add(lblNewLabel);
		
		
		JButton button_4 = new JButton("����");
		button_4.setBounds(233, 231, 105, 27);
		panel_5.add(button_4);
		
		ActionListener listener0 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  /*data2[0] = "";
			        data2[1] = ""; ���Ⱑ ������ �޴ºκ�
			        data2[2] = "";
			        data2[3] = "";
			        data2[4] = "";*/
			        
				int row = table_patient.getSelectedRow();
				boolean ismake = false;
				String time[] = new String[3];
				time[0] = "null";
				time[1] = "null";
				time[2] = "null";	
				
					
						
				  new Calendar(time, DBdatas, row, tableModel2);
				
		
			}
		};
		
		button_4.addActionListener(listener0);
		
		
		
		JButton btnNewButton_2 = new JButton("���� ����ϱ�");
		
		
		btnNewButton_2.setBounds(360, 231, 133, 27);
		panel_5.add(btnNewButton_2);
		
		ActionListener listener8 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/*  data2[0] = "";
			        data2[1] = "";
			        data2[2] = "";
			        data2[3] = "";
			        data2[4] = ""; */
			        
				int row = table_patient.getSelectedRow();
				DBdatas.������( row, data2, tableModel2);
			}
		};
		
		btnNewButton_2.addActionListener(listener8);
		
		
		
		JPanel panel_6 = new JPanel();
		panel_6.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_6.setBackground(Color.WHITE);
		panel_6.setBounds(14, 23, 252, 474);
		panel_3.add(panel_6);
		panel_6.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("ȯ�� ���");
		lblNewLabel_1.setBounds(14, 24, 62, 18);
		panel_6.add(lblNewLabel_1);
		
		Panel panel_7 = new Panel();
		panel_7.setBackground(Color.WHITE);
		panel_7.setBounds(14, 61, 228, 326);
		panel_6.add(panel_7);
		panel_7.setLayout(null);
		
		t_name = new JTextField();
		t_name.setBounds(14, 62, 200, 24);
		panel_7.add(t_name);
		t_name.setColumns(10);
		
		JLabel label_1 = new JLabel("�̸�");
		label_1.setBounds(14, 32, 62, 18);
		panel_7.add(label_1);
		
		JLabel label_2 = new JLabel("��ȭ ��ȣ");
		label_2.setBounds(14, 126, 62, 18);
		panel_7.add(label_2);
		
		t_pnum = new JTextField();
		t_pnum.setBounds(14, 156, 200, 24);
		panel_7.add(t_pnum);
		t_pnum.setColumns(10);
		
		JLabel label_3 = new JLabel("�ֹ� ��ȣ");
		label_3.setBounds(14, 219, 62, 18);
		panel_7.add(label_3);
		
		t_rnum = new JTextField();
		t_rnum.setBounds(14, 249, 200, 24);
		panel_7.add(t_rnum);
		t_rnum.setColumns(10);
		
		JButton btnNewButton_3 = new JButton("���");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DBdatas.addȯ��(t_name, t_pnum, t_rnum, data2, tableModel2);	//db data�� ȯ�ڸ� �߰��ϰ� ���̺��� ���� 
			
			}							//���̺� �ҷ����� �����ʿ�
			
		});
		btnNewButton_3.setBounds(137, 418, 105, 27);
		panel_6.add(btnNewButton_3);
		
		
		Panel panel_1 = new Panel();
		panel_1.setLayout(null);
		panel_1.setBackground(Color.LIGHT_GRAY);
		tabbedPane.addTab("�ǻ���ȸ", null, panel_1, null);
		
		Panel panel = new Panel();
		panel.setLayout(null);
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 0, 801, 556);
		panel_1.add(panel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(35, 68, 728, 430);	//35, 68, 728, 430);
		panel.add(scrollPane);
		
	      
	      JTable table_doctor = new JTable();
	       String calName3[]={"�ǻ��ȣ","�μ���ȣ","�ڵ�����ȣ","����","�̸�","�ֹι�ȣ"};
	       Object data3[] = new Object[6];
	       
	       DefaultTableModel tableModel3;
	       scrollPane.setViewportView(table_doctor);
	       tableModel3 = new DefaultTableModel(calName3,0);
	       table_doctor = new JTable(tableModel3);
	      
	   //    ActionListener listener1 = new ActionListener() {
	     //    public void actionPerformed(ActionEvent e) {
	       //     int row = table_patient.getSelectedRow();
	          DBdatas.DoctorTable(data3, tableModel3);
	        
	       //  }
	     // };
	      scrollPane.setViewportView(table_doctor);
	      Panel panel_2 = new Panel();
			panel_2.setLayout(null);
			panel_2.setBackground(Color.LIGHT_GRAY);
			tabbedPane.addTab("��ȣ����ȸ", null, panel_2, null);
			
			JScrollPane scrollPane_2 = new JScrollPane();
			scrollPane_2.setBounds(35, 68, 728, 430);
			panel_2.add(scrollPane_2);
	      
		
		JTable table_nurse = new JTable();
	    String calName4[]={"��ȣ���ȣ","�μ���ȣ","����","�̸�","��ȭ��ȣ","�ֹι�ȣ"};
	    Object data4[] = new Object[6];
	     
	    DefaultTableModel tableModel4;
	    tableModel4 = new DefaultTableModel(calName4,0);
	    table_nurse = new JTable(tableModel4);
	  //  ActionListener listener2 = new ActionListener() {
	  //    public void actionPerformed(ActionEvent e) {
	  //       int row = table_patient.getSelectedRow();
	        // new Nsearch( data4, tableModel4, mNURSE);
	         DBdatas.NurseTable(data4, tableModel4);
	        
	 //     }
	//   };
		scrollPane_2.setViewportView(table_nurse);
		
		
		
		
		
	/*	ActionListener listener = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new p_reg().setVisible(true);
			}
		};
		button_5.addActionListener(listener);   */ // ��ư �ؿ� �̰� ���̱�  ��ư ���� �Ϸ���
		
	}
};
	

		


