package frameclass;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import java.awt.Button;

public class BOOK extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	BOOK frame = new BOOK();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BOOK frame = new BOOK();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BOOK() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 575, 502);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\uC9C4\uB8CC \uB0B4\uC6A9");
		label.setBounds(32, 38, 62, 18);
		contentPane.add(label);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(32, 68, 492, 116);
		contentPane.add(scrollPane);
		
		textField = new JTextField();
		scrollPane.setViewportView(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("\uCC98\uBC29 \uB0B4\uC6A9\r\n");
		lblNewLabel.setBounds(32, 223, 62, 18);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(32, 251, 492, 116);
		contentPane.add(scrollPane_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		scrollPane_1.setViewportView(textField_1);
		
		Button button = new Button("�ݱ�");
		button.setBounds(437, 402, 87, 25);
		contentPane.add(button);
		
		ActionListener listener = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			contentPane.setVisible(false);
			
		}
	    };
	    button.addActionListener(listener);    
	
	}
}
