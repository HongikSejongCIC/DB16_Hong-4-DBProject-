package frameclass;

import java.io.Serializable;

public class BookInfo implements Serializable {
	
	
	String p_num;
	String p_name;
	String p_rnum;
	String p_pnum;
	String p_book;
	
	BookInfo( String p_num,	String p_name,	String p_rnum, 	String p_pnum, String p_book) {
		
		this.p_num = p_num;
		this.p_name = p_name;
		this.p_rnum = p_rnum;
		this.p_pnum = p_pnum;
		this.p_book = p_book;
		
	}

}
