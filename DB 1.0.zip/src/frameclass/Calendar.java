package frameclass;



import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import datas.DBdata;

import java.awt.Label;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Button;
import java.awt.Color;
import javax.swing.JButton;

public class Calendar extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	/*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					String arg[] = new String[3];
					Calendar frame = new Calendar(arg);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
*/
	/**
	 * Create the frame.
	 * @param tableModel2 
	 */
	public Calendar(String data[], DBdata DBdatas, int row, DefaultTableModel tableModel2 ) {
		this.setVisible(true);
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 363, 229);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(14, 55, 315, 58);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JComboBox combo_month = new JComboBox();
		combo_month.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				textField.setText((String) combo_month.getSelectedItem());
				
			}
		}
		);
		combo_month.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
		combo_month.setBounds(14, 13, 45, 29);
		panel.add(combo_month);
		
		
		JComboBox combo_day = new JComboBox();
		combo_day.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_1.setText((String) combo_day.getSelectedItem());
			}
		});
		combo_day.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		combo_day.setBounds(92, 13, 45, 29);
		panel.add(combo_day);
		

		JComboBox combo_time = new JComboBox();
		combo_time.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_2.setText((String) combo_time.getSelectedItem());
			}
		});
		combo_time.setModel(new DefaultComboBoxModel(new String[] {"9", "10", "11", "12", "13", "14", "15", "16"}));
		combo_time.setBounds(214, 13, 45, 29);
		panel.add(combo_time);
		

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(14, 115, 315, 48);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		
		JLabel label_2 = new JLabel("\uC6D4");
		label_2.setBounds(66, 18, 31, 18);
		panel.add(label_2);
		
		JLabel label_3 = new JLabel("\uC77C");
		label_3.setBounds(144, 18, 31, 18);
		panel.add(label_3);
		
		JLabel lblNewLabel_2 = new JLabel("\uC2DC");
		lblNewLabel_2.setBounds(268, 18, 22, 18);
		panel.add(lblNewLabel_2);
		
		Label label = new Label("\uC608\uC57D \uB0A0\uC9DC/\uC2DC\uAC04 \uC120\uD0DD");
		label.setBounds(14, 14, 162, 25);
		contentPane.add(label);
		
		JLabel lblNewLabel = new JLabel("\uC6D4");
		lblNewLabel.setBounds(50, 15, 31, 18);
		panel_1.add(lblNewLabel);
		
		JLabel label_1 = new JLabel("\uC77C");
		label_1.setBounds(109, 15, 31, 18);
		panel_1.add(label_1);
		
		JLabel label_4 = new JLabel("\uC2DC");
		label_4.setBounds(192, 15, 31, 18);
		panel_1.add(label_4);
		
		textField = new JTextField();
		textField.setBounds(14, 12, 31, 24);
		panel_1.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(72, 12, 31, 24);
		panel_1.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(154, 12, 31, 24);
		panel_1.add(textField_2);
		
		JButton btnNewButton = new JButton("����");
		btnNewButton.setBounds(235, 11, 65, 27);				//\uC608 \uC57D
		panel_1.add(btnNewButton);
	//	do{
		//	for(int i=0; i<3; i++)
				System.out.print("�ѹ�");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				data[0] = textField.getText();
				data[1] = textField_1.getText();
				data[2] = textField_2.getText();
				
				DBdatas.�������(row, data, tableModel2);
				
				dispose();
			}
		}
		);

		
		
		
	}


}
