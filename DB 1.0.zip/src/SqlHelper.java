


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import datas.DBdata;
import datas.��ȣ��;
import datas.�ǻ�;
import datas.ȯ��;
import frameclass.hospital;

public class SqlHelper {
	private static Statement stmt; 
	 private static ResultSet rs; //select
	 private static Connection con;
   private static void doSshTunnel(String strSshUser, String strSshPassword, String strSshHost, int nSshPort,
           String strRemoteHost, int nLocalPort, int nRemotePort) throws JSchException {
       final JSch jsch = new JSch();
       Session session = jsch.getSession(strSshUser, strSshHost, 22);
       session.setPassword(strSshPassword);

       final Properties config = new Properties();
       config.put("StrictHostKeyChecking", "no");
       session.setConfig(config);

       session.connect();
       session.setPortForwardingL(nLocalPort, strRemoteHost, nRemotePort);
   }
	public static void main(String args[]) {
		
		connect();
		
	
	}
	public static void connect() {
		 try {
	            String strSshUser = "db2_4"; // SSH loging username
	            String strSshPassword = "thom13579"; // SSH login password
	            String strSshHost = "hpclab.hongik.ac.kr"; // hostname or ip or
	                                                            // SSH server
	            int nSshPort = 22; // remote SSH host port number
	            String strRemoteHost = "127.0.0.1"; // hostname or
	                                                                    // ip of
	                                                                    // your
	                                                                    // database
	                                                                    // server
	            int nLocalPort = 50000; // local port number use to bind SSH tunnel
	            int nRemotePort = 3306; // remote port number of your database
	            String strDbUser = "db2_4"; // database loging username
	            String strDbPassword = "12312324"; // database login password

	            SqlHelper.doSshTunnel(strSshUser, strSshPassword, strSshHost, nSshPort, strRemoteHost, nLocalPort,
	                    nRemotePort);

	            Class.forName("com.mysql.jdbc.Driver");
	            con = DriverManager.getConnection("jdbc:mysql://localhost:" + nLocalPort, strDbUser,
	                    strDbPassword);
	            
	          
           // System.out.println("OracleDriver�� �ε��� ���������� �̷������ϴ�."); 
            System.out.println("�����ͺ��̽��� ���ῡ �����Ͽ����ϴ�."); 
            stmt = con.createStatement(); 
            String sql = "use testdb2_4";
            rs = stmt.executeQuery(sql);
            
            DBdata dbdatas = new DBdata(stmt, rs, con);
            
            ArrayList<��ȣ��> mNURSE = new ArrayList<��ȣ��>();
            String NURSE = "select * from NURSE";
            rs = stmt.executeQuery(NURSE);
            while (rs.next()){
               ��ȣ�� Data = new ��ȣ��();
               Data.setNURNO(rs.getInt("NURNO"));
               Data.setDNO(rs.getInt("DNO"));
               Data.setRANK(rs.getString("RANK"));
               Data.setNAME(rs.getString("NAME"));
               Data.setPHONENO(rs.getString("PHONENO"));
               Data.setPERNO(rs.getString("PERNO"));
               mNURSE.add(Data);
               System.out.println(Data.getNURNO()+" load");
            };
            dbdatas.��ȣ�縮��Ʈ=mNURSE;
            System.out.println("size = "+dbdatas.��ȣ�縮��Ʈ.size());
            ArrayList<�ǻ�> mDOCTOR = new ArrayList<�ǻ�>();
            String DOCTOR = "select * from DOCTOR";
            rs = stmt.executeQuery(DOCTOR);
            while (rs.next()){
            �ǻ� Data = new �ǻ�();
               Data.setDTNO(rs.getInt("DTNUM"));
               Data.setDNO(rs.getInt("DNO"));
               Data.setPHONENO(rs.getString("PHONENO"));
               Data.setRANK(rs.getString("RANK"));
               Data.setNAME(rs.getString("NAME"));
               Data.setPERNO(rs.getString("PERNO"));
               mDOCTOR.add(Data);
               System.out.println(Data.getDTNO()+" load");
            }
            dbdatas.�ǻ縮��Ʈ = mDOCTOR;
            ArrayList<ȯ��> mPATIENT = new ArrayList<ȯ��>();
            String PATIENT = "select * from PATIENT";
            rs = stmt.executeQuery(PATIENT);
            while (rs.next()){
              ȯ�� Data = new ȯ��();
               Data.setPATNO(rs.getString("PATNO"));
               Data.setNAME(rs.getString("NAME"));
               Data.setPERNO(rs.getInt("PERNO"));
               Data.setPHONENO(rs.getString("PHONENO"));
               mPATIENT.add(Data);
            }
            dbdatas.ȯ�ڸ���Ʈ=mPATIENT;
      
			new hospital(dbdatas).setVisible(true);
       	
			
			//rs.close(); 
       // stmt.close(); 
       //  con.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            System.out.print("�ε� ��");
            
        }
     
    
            

	}
}
