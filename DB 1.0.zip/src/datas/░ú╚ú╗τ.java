package datas;

import javax.swing.table.DefaultTableModel;

public class ��ȣ�� {
	   private int NURNO;
	   private int DNO;
	   private String RANK;
	   private String NAME;
	   private String PHONENO;
	   private String PERNO;
	   
	   public int getNURNO() {
	      return NURNO;
	   }
	   public void setNURNO(int NURNO) {
	      this.NURNO = NURNO;
	   }
	   public int getDNO() {
	      return DNO;
	   }
	   public void setDNO(int DNO) {
	      this.DNO = DNO;
	   }
	   public String getRANK() {
	      return RANK;
	   }
	   public void setRANK(String RANK) {
	      this.RANK = RANK;
	   }
	   public String getNAME() {
	      return NAME;
	   }
	   public void setNAME(String NAME) {
	      this.NAME = NAME;
	   }
	   public String getPHONENO() {
	      return PHONENO;
	   }
	   public void setPHONENO(String PHONENO) {
	      this.PHONENO = PHONENO;
	   }
	   public String getPERNO() {
	      return PERNO;
	   }
	   public void setPERNO(String PERNO) {
	      this.PERNO = PERNO;
	   }
	
	}