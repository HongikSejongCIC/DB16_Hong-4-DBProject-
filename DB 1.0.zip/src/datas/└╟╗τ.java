package datas;

public class �ǻ� {
	   private int DTNO;
	   private int DNO;
	   private String PHONENO;
	   private String RANK;
	   private String NAME;
	   private String PERNO;
	   
	   public int getDTNO() {
	      return DTNO;
	   }
	   public void setDTNO(int DTNO) {
	      this.DTNO = DTNO;
	   }
	   public int getDNO() {
	      return DNO;
	   }
	   public void setDNO(int DNO) {
	      this.DNO = DNO;
	   }
	   public String getPHONENO() {
	      return PHONENO;
	   }
	   public void setPHONENO(String PHONENO) {
	      this.PHONENO = PHONENO;
	   }
	   public String getRANK() {
	      return RANK;
	   }
	   public void setRANK(String RANK) {
	      this.RANK = RANK;
	   }
	   public String getNAME() {
	      return NAME;
	   }
	   public void setNAME(String NAME) {
	      this.NAME = NAME;
	   }
	   public String getPERNO() {
	      return PERNO;
	   }
	   public void setPERNO(String PERNO) {
	      this.PERNO = PERNO;
	   }
	}