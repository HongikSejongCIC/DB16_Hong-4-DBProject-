package datas;

public class ȯ�� {
	private String NAME;
	private String PATNO;
	private int PERNO;	//int
	private String PHONENO;	//int
	private String ���࿩��; 
	private String FAMILY;
	private String INSURANCE;
	
	public ȯ��(){
		���࿩�� = "x";
	}
	public ȯ��(String name, String patno, int perno, String phonenum){
		this.NAME = name;
		this.PATNO = patno;
		this.PERNO = perno;
		this.PHONENO = phonenum;
		���࿩�� = "x";
		

		
		
	}
	public String[] return_data(){
		String data[] = new String[7];
		data[0] = PATNO;
        data[1] = NAME;
        data[2] = String.valueOf(PHONENO);
        data[3] = String.valueOf(PERNO);
        data[4] = ���࿩��;	//���࿩��
        data[5] = FAMILY;
    	data[6] =INSURANCE;

        return data;
	}
	public String getPATNO() {
		return PATNO;
	}
	public void setPATNO(String PATNO) {
		this.PATNO = PATNO;
	}
	public String getNAME() {
		return NAME;
	}
	public void setNAME(String NAME) {
		this.NAME = NAME;
	}
	public int getPERNO() {
		return PERNO;
	}
	public void setPERNO(int PERNO) {
		this.PERNO = PERNO;
	}
	public String getPHONENO() {
		return PHONENO;
	}
	public void setPHONENO(String PHONENO) {
		this.PHONENO = PHONENO;
	}
	public String getFAMILY() {
		return FAMILY;
	}
	public void setFAMILY(String FAMILY) {
		this.FAMILY = FAMILY;
	}
	public String getINSURANCE() {
		return INSURANCE;
	}
	public void setINSURANCE(String INSURANCE) {
		this.INSURANCE = INSURANCE;
	}
	String getInsertSql() {

		String key = PATNO.substring(2);
		String sql 
		= "INSERT INTO PATIENT(PATNO,NAME, PERNO, PHONENO, FAMILY, INSURANCE, ETC)"
			+"VALUE ("+key+", "+'"'+ NAME+'"'+"," +PERNO+","+'"'+PHONENO+'"'+","+'"'+FAMILY+'"'+","+'"'+INSURANCE+'"'+","+'"'+"etc"+'"'+");";
		
		System.out.println("sql = " + sql);
		return sql;
	}
	
	
}
