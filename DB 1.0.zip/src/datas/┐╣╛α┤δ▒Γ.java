package datas;

import java.io.Serializable;

public class ������ implements Serializable {
	
	
	String p_num;
	String p_name;
	String p_rnum;
	String p_pnum;
	String p_book;
	
	������( String p_num,	String p_name,	String p_rnum, 	String p_pnum, String p_book) {
		
		this.p_num = p_num;	//ȯ�ڹ�ȣ
		this.p_name = p_name;	//�̸�
		this.p_rnum = p_rnum;	//����
		this.p_pnum = p_pnum;	//�ֹ�
		this.p_book = p_book;	//����
		
	}
	public String getp_num(){
		return p_num;
	}
	public String getp_name(){
		return p_name;
	}
	public String getp_rnum(){
		return p_rnum;
	}
	public String getp_pnum(){
		return p_pnum;
	}
	public String getp_book(){
		return p_book;
	}

}